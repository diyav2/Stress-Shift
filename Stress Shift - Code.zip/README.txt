1] Python Processor
- Runs in Python, called in command prompt/terminal
- Receives real-time sensor data from the ESP32 over WiFi (UDP)
- Signal processing (filtering, complementary fusion, torque computation)
- Inverse dynamics modeling to estimate knee joint torque
- Generates adaptive thresholds to calculate intervention level
- Sends actuator commands (flex / extend / neutral) back to the ESP32

2] ESP 32 Code *
- C++ code, uploaded to ESP 32 microcontroller through Arduino IDE
- Connects to WiFi and sends IMU + FSR sensor data
- Controls four servos (2 positional, 2 continuous rotation)
- Real-time control commands from Python processor
- Proportional flexion/extension based on adaptive torque levels

* Embedded hardware control layer of the system